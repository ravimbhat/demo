package com.schwab.demo.controller;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class CourseController {
    Logger logger = LoggerFactory.getLogger(CourseController.class);
    @GetMapping("/coursedetails/{courseId}")
    public String getCourseDetails(@PathVariable String courseId) {
        logger.info("Controller called");
        return "{\"courseName\":\"Course "+courseId+" for students \", \"courseId\":"+courseId+"}";
    }
}
